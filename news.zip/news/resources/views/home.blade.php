@extends('template_backend.home')

@section('content')

<h1>Ini Adalah content</h1>
    
@endsection